﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using TeacherModule.Models;
    using TeacherModule.Respositpries;

namespace TeacherModule.Controllers
{
    [Route("api/[controller]")]
    public class TeacherController : Controller
    {
        private readonly ITeacherRepository teacherRepository;
             public TeacherController(ITeacherRepository teacherRepository)
        {
            this.teacherRepository = teacherRepository;
        }
        //Endpoints
        [HttpGet,Route("GetAll")]
        public IActionResult GetAll()
        {
            try
            {
                return Ok(teacherRepository.GetAll());
            }
            catch (Exception)
            {

                throw;
            }
        }
        [HttpGet, Route("GetAllTeacherByStd/{std}")]
        public IActionResult GetAllByStd(string std)
        {
            try
            {
                return Ok(teacherRepository.GetTeacherByStd(std));
            }
            catch (Exception)
            {

                throw;
            }
        }
        [HttpGet, Route("GetAllTeacherBySubject/{Subject}")]
        public IActionResult GetAllBySubject(string subject)
        {
            try
            {
                return Ok(teacherRepository.GetTeacherBySubject(subject));
            }
            catch (Exception)
            {

                throw;
            }
        }
        [HttpGet, Route("GetTeacher/{id}")]
        public IActionResult GetStaff(string id)
        {
            try
            {
                return Ok(teacherRepository.GetTeacher(id));
            }
            catch (Exception)
            {

                throw;
            }
        }
        [HttpPost, Route("AddTeacher")]
        public IActionResult AddTeacher(Teacher teacher)
        {
            try
            {
                teacherRepository.AddTeacher(teacher);
                return Ok(teacher);
            }
            catch (Exception)
            {

                throw;
            }
        }
        [HttpPut, Route("EditTeacher")]
        public IActionResult Edittrch(Teacher teacher)
        {
            try
            {
                teacherRepository.UpdateTeacher(teacher);
                return Ok(teacher);
            }
            catch (Exception)
            {

                throw;
            }
        }
        [HttpDelete, Route("Delete/{id}")]
        public IActionResult Deletetrch(string id)
        {
            try
            {
                teacherRepository.DeleteTeacher(id);
                return Ok("Teacher Deleted");
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
    

