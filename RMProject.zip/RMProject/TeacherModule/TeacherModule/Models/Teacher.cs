﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TeacherModule.Models
{
    public class Teacher
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public string TeacherId { get; set; }
        public string Name { get; set; }
        public string[] Subjects { get; set; }
        public string[] stds { get; set; }
    }
}

