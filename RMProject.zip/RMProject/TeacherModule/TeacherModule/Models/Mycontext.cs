﻿using Microsoft.EntityFrameworkCore;
using System.Data.Common;

namespace TeacherModule.Models
{
    public class Mycontext:DbContext
    {
        private readonly IConfiguration configuration;

        public Mycontext(IConfiguration configuration)
        {
            this.configuration = configuration;
        }
        public DbSet<Teacher> Teachers { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(configuration.GetConnectionString("Myconnection"));
        }
    }
}
