﻿using TeacherModule.Models;

namespace TeacherModule.Respositpries
{
    public interface ITeacherRepository
    {
        void AddTeacher(Teacher teacher);
        void UpdateTeacher(Teacher teacher);
        void DeleteTeacher(String teacherId);
        List<Teacher> GetAll();
        List<Teacher> GetTeacherByStd(string std);
        List<Teacher> GetTeacherBySubject(string subject);
        Teacher GetTeacher(string teacherId);
    }
}

