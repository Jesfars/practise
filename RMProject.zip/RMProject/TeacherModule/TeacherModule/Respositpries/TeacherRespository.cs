﻿using TeacherModule.Models;

namespace TeacherModule.Respositpries
{
    public class TeacherRespository : ITeacherRepository
    {
       
        private readonly Mycontext context;
       public TeacherRespository(Mycontext context)
        {
            this.context = context;
        }
        public void AddTeacher(Teacher teacher)
        {
            context.Teachers.Add(teacher);
            context.SaveChanges();

        }

        public void DeleteTeacher(String teacherId)
        {
            Teacher teacher= context.Teachers.SingleOrDefault(s => s.TeacherId == teacherId);
           context.Teachers.Remove(teacher);
            context.SaveChanges();
        }

        public List<Teacher> GetAll()
        {
            return context.Teachers.ToList();
        }

        public Teacher GetTeacher(string teacherId)
        {
            return context.Teachers.SingleOrDefault(s => s.TeacherId == teacherId);
        }

        public List<Teacher> GetTeacherByStd(string std)
        {
            /*List<Teacher> teachersithStd = (from s in _teachers
                                            where s.stds.Contains(std)
                                            select s).ToList();*/

            return context.Teachers.Where(x=>x.TeacherId ==std).ToList();
        }
        public List<Teacher> GetTeacherBySubject(string subject)
        {
            /*List<Teacher>teacherwithSubject =new List<Teacher>();
             foreach (var teacher in _teachers)
             {
                 foreach (var s in  teacher.Subjects)
                 {
                     if(s == subject)
                     {
                         teacherwithSubject.Add(teacher);
                     }
                 }
             }   
             return teacherwithSubject;*/
            return context.Teachers.Where(x => x.TeacherId == subject).ToList();

        }

        public void UpdateTeacher(Teacher teacher)
        {
            /*foreach(var s in _teachers)
            {
                if(s.TeacherId==teacher.TeacherId)
                {
                    s.Name = teacher.Name;
                    s.Subjects = teacher.Subjects;
                }
            }*/
            context.Teachers.Update(teacher);
            context.SaveChanges();
        }
    }
}
